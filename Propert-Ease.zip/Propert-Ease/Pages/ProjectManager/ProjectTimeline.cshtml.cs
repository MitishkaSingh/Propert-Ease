using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace Propert_Ease.Pages.ProjectManager
{
    public class ProjectTimelineModel : PageModel
    {
        public class ProjectPhase
        {
            public string PhaseName { get; set; } = string.Empty;
            public string Deadline { get; set; } = string.Empty;
            public string Status { get; set; } = string.Empty;
        }

        [BindProperty]
        public List<ProjectPhase> Phases { get; set; } = new();

        [BindProperty]
        public ProjectPhase NewPhase { get; set; } = new();

        public void OnGet()
        {
            // Example static data
            Phases = new List<ProjectPhase>
            {
                new ProjectPhase { PhaseName = "Planning", Deadline = "2025-11-15", Status = "Completed" },
                new ProjectPhase { PhaseName = "Design", Deadline = "2025-12-05", Status = "In Progress" },
                new ProjectPhase { PhaseName = "Development", Deadline = "2026-01-10", Status = "Pending" }
            };
        }

        public IActionResult OnPostAddPhase()
        {
            if (!string.IsNullOrWhiteSpace(NewPhase.PhaseName))
            {
                Phases.Add(NewPhase);
            }

            return Page();
        }
    }
}
