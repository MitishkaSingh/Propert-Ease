using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace Propert_Ease.Pages.ProjectManager
{
    public class ManagerMessagingModel : PageModel
    {
        public class Message
        {
            public string Sender { get; set; } = string.Empty;
            public string Content { get; set; } = string.Empty;
        }

        public static List<Message> ChatMessages { get; set; } = new()
        {
            new Message { Sender = "Contractor John", Content = "Report submitted successfully." },
            new Message { Sender = "You", Content = "Thank you, please proceed with the next phase." }
        };

        [BindProperty]
        public string NewMessage { get; set; } = string.Empty;

        public void OnGet()
        {
        }

        public IActionResult OnPostSend()
        {
            if (!string.IsNullOrWhiteSpace(NewMessage))
            {
                ChatMessages.Add(new Message { Sender = "You", Content = NewMessage });
            }

            return Page();
        }
    }
}
