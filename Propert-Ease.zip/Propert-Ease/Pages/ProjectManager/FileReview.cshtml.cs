using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Propert_Ease.Pages.ProjectManager
{
    public class FileReviewModel : PageModel
    {
        [BindProperty] public IFormFile? UploadedFile { get; set; }
        [BindProperty] public string ReviewNotes { get; set; } = string.Empty;
        [BindProperty] public bool? Approved { get; set; }
        [BindProperty] public int SelectedProjectId { get; set; }

        public string? ResultMessage { get; set; }

        public List<ProjectSubmission> Projects { get; set; } = new();
        public ProjectSubmission? SelectedProject { get; set; }

        public void OnGet()
        {
            LoadSampleProjects();
            Projects = ProjectData.Submissions;
        }

        public void OnPostSelect(int selectedId)
        {
            LoadSampleProjects();
            Projects = ProjectData.Submissions;
            SelectedProjectId = selectedId;
            SelectedProject = ProjectData.Submissions.FirstOrDefault(p => p.Id == selectedId);
        }

        public async Task<IActionResult> OnPostAsync(string action)
        {
            LoadSampleProjects();
            Projects = ProjectData.Submissions;

            SelectedProject = Projects.FirstOrDefault(p => p.Id == SelectedProjectId);

            if (SelectedProject == null)
            {
                ResultMessage = "Please select a project first.";
                return Page();
            }

            if (UploadedFile != null)
            {
                SelectedProject.UploadedFiles.Add(UploadedFile.FileName);
                var filePath = Path.Combine("wwwroot/uploads", UploadedFile.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await UploadedFile.CopyToAsync(stream);
                }
                ResultMessage = $"File '{UploadedFile.FileName}' uploaded successfully.";
            }

            // Update review notes
            SelectedProject.ReviewNotes = ReviewNotes;

            // Handle approve/reject
            if (action == "Approve")
            {
                SelectedProject.Approved = true;
                ResultMessage = $"Project '{SelectedProject.Name}' approved.";
            }
            else if (action == "Reject")
            {
                SelectedProject.Approved = false;
                ResultMessage = $"Project '{SelectedProject.Name}' rejected.";
            }

            return Page();
        }

        private void LoadSampleProjects()
        {
            if (!ProjectData.Submissions.Any())
            {
                ProjectData.Submissions.AddRange(new List<ProjectSubmission>
                {
                    new ProjectSubmission { Id = 1, Name = "Apartment A101 Renovation" },
                    new ProjectSubmission { Id = 2, Name = "Building B Painting" },
                    new ProjectSubmission { Id = 3, Name = "Office Complex C2 Electrical" },
                    new ProjectSubmission { Id = 4, Name = "Apartment D5 Flooring Repair" }
                });
            }
        }
    }

    public static class ProjectData
    {
        public static List<ProjectSubmission> Submissions { get; } = new List<ProjectSubmission>();
    }

    public class ProjectSubmission
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public List<string> UploadedFiles { get; set; } = new List<string>();
        public bool? Approved { get; set; } = null;
        public string ReviewNotes { get; set; } = string.Empty;
    }
}
