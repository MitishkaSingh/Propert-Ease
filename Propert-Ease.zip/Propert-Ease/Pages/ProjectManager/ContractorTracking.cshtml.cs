using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace Propert_Ease.Pages.ProjectManager
{
    public class ContractorTrackingModel : PageModel
    {
        public class Contractor
        {
            public string Name { get; set; } = string.Empty;
            public string Specialization { get; set; } = string.Empty;
            public string Contact { get; set; } = string.Empty;
            public double Rating { get; set; }
        }

        public List<Contractor> Contractors { get; set; } = new();
        [BindProperty] public string SelectedContractor { get; set; } = string.Empty;
        [BindProperty] public double Rating { get; set; }

        public Contractor? DisplayedContractor { get; set; }

        public void OnGet()
        {
            LoadSampleContractors();
        }

        public void OnPostSelectContractor()
        {
            LoadSampleContractors();
            DisplayedContractor = Contractors.Find(c => c.Name == SelectedContractor);
        }

        public IActionResult OnPostRateContractor()
        {
            LoadSampleContractors();
            var contractor = Contractors.Find(c => c.Name == SelectedContractor);
            if (contractor != null)
            {
                contractor.Rating = Rating;
                TempData["Message"] = $"You rated {contractor.Name} {Rating} stars!";
            }
            return RedirectToPage();
        }

        private void LoadSampleContractors()
        {
            Contractors = new List<Contractor>
            {
                new Contractor { Name = "John Dlamini", Specialization = "Electrical", Contact = "johnd@buildpro.co.za", Rating = 4.8 },
                new Contractor { Name = "Sara Naidoo", Specialization = "Plumbing", Contact = "saranaidoo@pipesfix.co.za", Rating = 4.2 },
                new Contractor { Name = "Michael van Rooyen", Specialization = "Carpentry", Contact = "mike@carpentrypros.co.za", Rating = 4.5 },
                new Contractor { Name = "Lindiwe Mokoena", Specialization = "Painting", Contact = "lindiwem@paintmasters.co.za", Rating = 4.7 } // New 4th contractor
            };
        }
    }
}
