using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace Propert_Ease.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        public string Email { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; } = "";

        public string? Message { get; set; }
        public string? SuccessMessage { get; set; }
        public string? RedirectUrl { get; set; }

        private readonly List<AppUser> Users = new List<AppUser>
        {
            new AppUser { Email = "client1@gmail.com", Password = "client123", Role = "Client" },
            new AppUser { Email = "contractor1@gmail.com", Password = "cont123", Role = "Contractor" },
            new AppUser { Email = "admin1@gmail.com", Password = "admin123", Role = "Admin" },
            new AppUser { Email = "pm1@gmail.com", Password = "pmanager123", Role = "ProjectManager" }
        };

        public void OnGet() { }

        public IActionResult OnPost()
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    Message = "Please fill in all required fields correctly.";
                    return Page();
                }

                var user = Users.FirstOrDefault(u =>
                    u.Email.Equals(Email, StringComparison.OrdinalIgnoreCase) &&
                    u.Password == Password);

                if (user == null)
                {
                    Message = "Invalid email or password!";
                    return Page();
                }

                // Determine redirect URL based on role
                RedirectUrl = user.Role switch
                {
                    "Client" => Url.Page("/Dashboard/ClientDashboard"),
                    "Contractor" => Url.Page("/Dashboard/ContractorDashboard"),
                    "Admin" => Url.Page("/Dashboard/AdminDashboard"),
                    "ProjectManager" => Url.Page("/Dashboard/ProjectManagerDashboard"),
                    _ => Url.Page("/Index")
                };

                // Show success message first
                SuccessMessage = "Login successful! Redirecting to your dashboard...";
                return Page();
            }
            catch (Exception ex)
            {
                Message = $"An unexpected error occurred: {ex.Message}";
                return Page();
            }
        }
    }

    public class AppUser
    {
        public string Email { get; set; } = "";
        public string Password { get; set; } = "";
        public string Role { get; set; } = "";
    }
}
