using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Contractor
{
    public class ContractorMessagingModel : PageModel
    {
        public class ChatMessage
        {
            public string Sender { get; set; } = "";
            public string Text { get; set; } = "";
            public DateTime Timestamp { get; set; }
        }

        private static readonly List<ChatMessage> SharedMessages = new()
        {
            new ChatMessage { Sender = "Client", Text = "Hi, how's the repair going?", Timestamp = DateTime.Now.AddMinutes(-5) },
            new ChatMessage { Sender = "Contractor", Text = "Almost done, should be finished soon.", Timestamp = DateTime.Now.AddMinutes(-2) }
        };

        [BindProperty]
        public string NewMessage { get; set; } = "";

        public List<ChatMessage> Messages { get; set; } = new();

        public void OnGet()
        {
            Messages = SharedMessages.ToList();
        }

        public IActionResult OnPost()
        {
            if (!string.IsNullOrWhiteSpace(NewMessage))
            {
                SharedMessages.Add(new ChatMessage
                {
                    Sender = "Contractor",
                    Text = NewMessage,
                    Timestamp = DateTime.Now
                });
            }

            return RedirectToPage();
        }
    }
}
