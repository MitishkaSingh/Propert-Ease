using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Propert_Ease.Pages.Contractor
{
    public class SubmitReportModel : PageModel
    {
        [BindProperty]
        public string ReportText { get; set; } = "";

        [BindProperty]
        public IFormFile? EvidenceFile { get; set; }

        public string Message { get; set; } = "";

        public static List<ReportItem> DraftReports { get; } = new();
        public static List<ReportItem> SubmittedReports { get; } = new();

        public ReportItem? SelectedReport { get; set; }
        public int SelectedIndex { get; set; } = -1;

        public void OnGet(int? draftIndex, int? submittedIndex)
        {
            if (draftIndex.HasValue)
            {
                SelectedReport = DraftReports[draftIndex.Value];
                ReportText = SelectedReport.ReportText;
                SelectedIndex = draftIndex.Value;
            }
            else if (submittedIndex.HasValue)
            {
                SelectedReport = SubmittedReports[submittedIndex.Value];
                ReportText = SelectedReport.ReportText;
                SelectedIndex = submittedIndex.Value;
            }
        }

        public async Task<IActionResult> OnPostSaveDraftAsync(int ReportIndex = -1)
        {
            string fileName = EvidenceFile?.FileName ?? "No file attached";
            string filePath = "";

            if (EvidenceFile != null)
            {
                Directory.CreateDirectory("wwwroot/uploads/drafts");
                filePath = Path.Combine("wwwroot/uploads/drafts", fileName);
                using var stream = new FileStream(filePath, FileMode.Create);
                await EvidenceFile.CopyToAsync(stream);
            }

            if (ReportIndex >= 0 && ReportIndex < DraftReports.Count)
            {
                // Update existing draft
                var existing = DraftReports[ReportIndex];
                existing.ReportText = ReportText;
                if (!string.IsNullOrEmpty(fileName) && EvidenceFile != null)
                {
                    existing.FileName = fileName;
                    existing.FilePath = $"/uploads/drafts/{fileName}";
                }
                existing.DateSaved = DateTime.Now;
            }
            else
            {
                DraftReports.Add(new ReportItem
                {
                    ReportText = ReportText,
                    FileName = fileName,
                    FilePath = EvidenceFile != null ? $"/uploads/drafts/{fileName}" : "",
                    DateSaved = DateTime.Now,
                    Status = "Draft"
                });
            }

            Message = "? Draft saved successfully.";
            return Page();
        }

        public async Task<IActionResult> OnPostSubmitAsync(int ReportIndex = -1)
        {
            string fileName = EvidenceFile?.FileName ?? "No file attached";
            string filePath = "";

            if (EvidenceFile != null)
            {
                Directory.CreateDirectory("wwwroot/uploads/submitted");
                filePath = Path.Combine("wwwroot/uploads/submitted", fileName);
                using var stream = new FileStream(filePath, FileMode.Create);
                await EvidenceFile.CopyToAsync(stream);
            }

            if (ReportIndex >= 0 && ReportIndex < DraftReports.Count)
            {
                // Move draft to submitted
                var draft = DraftReports[ReportIndex];
                DraftReports.RemoveAt(ReportIndex);
                SubmittedReports.Add(new ReportItem
                {
                    ReportText = ReportText,
                    FileName = !string.IsNullOrEmpty(fileName) && EvidenceFile != null ? fileName : draft.FileName,
                    FilePath = !string.IsNullOrEmpty(filePath) ? $"/uploads/submitted/{fileName}" : draft.FilePath,
                    DateSaved = DateTime.Now,
                    Status = "Submitted"
                });
            }
            else
            {
                SubmittedReports.Add(new ReportItem
                {
                    ReportText = ReportText,
                    FileName = fileName,
                    FilePath = EvidenceFile != null ? $"/uploads/submitted/{fileName}" : "",
                    DateSaved = DateTime.Now,
                    Status = "Submitted"
                });
            }

            Message = "? Report submitted successfully.";
            return Page();
        }

        public class ReportItem
        {
            public string ReportText { get; set; } = "";
            public string FileName { get; set; } = "";
            public string FilePath { get; set; } = "";
            public DateTime DateSaved { get; set; }
            public string Status { get; set; } = "";
        }
    }
}
