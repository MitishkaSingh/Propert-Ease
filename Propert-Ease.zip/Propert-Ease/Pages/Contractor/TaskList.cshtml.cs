using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Contractor
{
    public class TaskListModel : PageModel
    {
        [BindProperty]
        public int Id { get; set; }

        [BindProperty]
        public string ProjectDetails { get; set; } = string.Empty;

        [BindProperty]
        public string TaskName { get; set; } = string.Empty;

        [BindProperty]
        public string Status { get; set; } = string.Empty;

        public List<ContractorTask> Tasks { get; set; } = ContractorTaskData.Tasks;
        public ContractorTask? SelectedTask { get; set; }

        public void OnGet(int? id)
        {
            if (id.HasValue)
            {
                SelectedTask = Tasks.FirstOrDefault(t => t.Id == id.Value);
            }
        }

        public void OnPost()
        {
            var task = Tasks.FirstOrDefault(t => t.Id == Id);
            if (task != null)
            {
                task.Status = Status;
            }

            Tasks = ContractorTaskData.Tasks;
        }
    }

    public class ContractorTask
    {
        public int Id { get; set; }
        public string ProjectDetails { get; set; } = string.Empty;
        public string TaskName { get; set; } = string.Empty;
        public string Status { get; set; } = "Pending";
    }

    public static class ContractorTaskData
    {
        public static List<ContractorTask> Tasks { get; }

        static ContractorTaskData()
        {
            Tasks = new List<ContractorTask>
            {
                new ContractorTask { Id = 1, ProjectDetails = "Apartment A101 - Plumbing Upgrade", TaskName = "Fix bathroom leakage", Status = "Pending" },
                new ContractorTask { Id = 2, ProjectDetails = "Building B - Exterior Painting", TaskName = "Repaint west wall", Status = "In Progress" },
                new ContractorTask { Id = 3, ProjectDetails = "Office Complex C2 - Electrical Maintenance", TaskName = "Replace light fixtures", Status = "Completed" },
                new ContractorTask { Id = 4, ProjectDetails = "Apartment D5 - Flooring Repair", TaskName = "Repair cracked tiles", Status = "Pending" }
            };
        }
    }
}
