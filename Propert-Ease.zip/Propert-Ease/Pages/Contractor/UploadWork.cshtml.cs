using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;

namespace Propert_Ease.Pages.Contractor
{
    public class UploadWorkModel : PageModel
    {
        public class ContractorTask
        {
            public int Id { get; set; }
            public string ProjectDetails { get; set; } = "";
            public string TaskName { get; set; } = "";
            public string Status { get; set; } = "";
            public List<string> UploadedFiles { get; set; } = new();
        }

        // Static list of tasks shared by all contractors
        public static List<ContractorTask> Tasks = new()
        {
            new ContractorTask { Id = 1, ProjectDetails = "Apartment A101 - Plumbing Upgrade", TaskName = "Fix bathroom leakage", Status = "Pending" },
            new ContractorTask { Id = 2, ProjectDetails = "Building B - Exterior Painting", TaskName = "Repaint west wall", Status = "In Progress" },
            new ContractorTask { Id = 3, ProjectDetails = "Office Complex C2 - Electrical Maintenance", TaskName = "Replace light fixtures", Status = "Completed" },
            new ContractorTask { Id = 4, ProjectDetails = "Apartment D5 - Flooring Repair", TaskName = "Repair cracked tiles", Status = "Pending" }
        };

        public List<ContractorTask> TasksView => Tasks;

        public ContractorTask? SelectedTask { get; set; }

        [BindProperty] public IFormFile? ImageFile { get; set; }
        [BindProperty] public IFormFile? VideoFile { get; set; }
        [BindProperty] public IFormFile? ReportFile { get; set; }

        public void OnGet(int? id)
        {
            if (id.HasValue)
                SelectedTask = Tasks.FirstOrDefault(t => t.Id == id.Value);
        }

        public async Task<IActionResult> OnPostAsync(int TaskId)
        {
            var task = Tasks.FirstOrDefault(t => t.Id == TaskId);
            if (task == null) return RedirectToPage();

            var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            async Task SaveFile(IFormFile? file)
            {
                if (file != null && file.Length > 0)
                {
                    var uniqueName = $"{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";
                    var filePath = Path.Combine(uploadsFolder, uniqueName);
                    using var stream = new FileStream(filePath, FileMode.Create);
                    await file.CopyToAsync(stream);
                    var relativePath = $"/uploads/{uniqueName}";
                    task.UploadedFiles.Add(relativePath);
                }
            }

            await SaveFile(ImageFile);
            await SaveFile(VideoFile);
            await SaveFile(ReportFile);

            return RedirectToPage(new { id = task.Id });
        }
    }
}
