using Microsoft.AspNetCore.Mvc.RazorPages;
using Propert_Ease.Pages.Client;
using System.Collections.Generic;

namespace Propert_Ease.Pages.Dashboard
{
    public class ClientDashboardModel : PageModel
    {
        public List<MaintenanceRequest> Requests { get; set; } = new();

        public void OnGet()
        {
            // Load all maintenance requests from shared static data
            Requests = MaintenanceData.Requests.ToList();
        }
    }
}
