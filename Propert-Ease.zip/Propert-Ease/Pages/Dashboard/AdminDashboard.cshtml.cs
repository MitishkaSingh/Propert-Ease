using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Dashboard
{
    public class AdminDashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
