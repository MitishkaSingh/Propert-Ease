using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Dashboard
{
    public class ProjectManagerDashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
