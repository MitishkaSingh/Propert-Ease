using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;

namespace Propert_Ease.Pages.Admin
{
    public class AssignTasksModel : PageModel
    {
        // Model for task assignment
        public class TaskAssignment
        {
            public string Task { get; set; } = "";
            public string Contractor { get; set; } = "";
        }

        // In-memory storage (shared across all users for this session)
        public static List<TaskAssignment> AssignedTasksStore { get; set; } = new();

        [BindProperty]
        public string SelectedTask { get; set; }

        [BindProperty]
        public string SelectedContractor { get; set; }

        public List<string> Tasks { get; set; } = new();
        public List<string> Contractors { get; set; } = new();

        public List<SelectListItem> TaskOptions { get; set; } = new();
        public List<SelectListItem> ContractorOptions { get; set; } = new();

        public List<TaskAssignment> AssignedTasks => AssignedTasksStore;

        public void OnGet()
        {
            LoadData();
        }

        public void OnPost()
        {
            LoadData();

            if (!string.IsNullOrEmpty(SelectedTask) && !string.IsNullOrEmpty(SelectedContractor))
            {
                AssignedTasksStore.Add(new TaskAssignment
                {
                    Task = SelectedTask,
                    Contractor = SelectedContractor
                });

                TempData["Message"] = $"Task '{SelectedTask}' assigned to '{SelectedContractor}'.";
            }
        }

        private void LoadData()
        {
            Tasks = new List<string> { "Inspect Site", "Repair Equipment", "Install Solar Panels", "Quality Check" };
            Contractors = new List<string> { "TechBuild Pty", "GreenWorks Ltd", "EcoFix Contractors", "BuildPro SA" };

            TaskOptions = Tasks.Select(t => new SelectListItem { Value = t, Text = t }).ToList();
            ContractorOptions = Contractors.Select(c => new SelectListItem { Value = c, Text = c }).ToList();
        }
    }
}
