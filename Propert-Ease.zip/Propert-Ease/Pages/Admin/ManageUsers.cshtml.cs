using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Admin
{
    public class ManageUsersModel : PageModel
    {
        public class UserInfo
        {
            public string Name { get; set; } = string.Empty;
            public string Role { get; set; } = "Client";
            public string Status { get; set; } = "Active";
        }

        [BindProperty]
        public string SelectedUser { get; set; } = string.Empty;
        [BindProperty]
        public string SelectedRole { get; set; } = string.Empty;
        [BindProperty]
        public string AccountStatus { get; set; } = string.Empty;

        public List<UserInfo> Users { get; set; } = new();

        public void OnGet()
        {
            // Load users (in real case, from DB)
            Users = new List<UserInfo>
            {
                new UserInfo { Name = "JohnDoe", Role = "Admin", Status = "Active" },
                new UserInfo { Name = "JaneClient", Role = "Client", Status = "Pending" },
                new UserInfo { Name = "MarkContractor", Role = "Contractor", Status = "Active" }
            };
        }

        public void OnPost()
        {
            if (!string.IsNullOrEmpty(SelectedUser) && !string.IsNullOrEmpty(SelectedRole) && !string.IsNullOrEmpty(AccountStatus))
            {
                // Update the in-memory user
                var user = Users.Find(u => u.Name == SelectedUser);
                if (user != null)
                {
                    user.Role = SelectedRole;
                    user.Status = AccountStatus;
                }

                TempData["Message"] = $"User '{SelectedUser}' updated to role '{SelectedRole}' with status '{AccountStatus}'.";
            }
            else
            {
                TempData["Message"] = "Please select a user, role, and status.";
            }

            OnGet(); // Refresh the list for display
        }
    }
}
