using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;

namespace Propert_Ease.Pages.Admin
{
    public class ReportsModel : PageModel
    {
        public class Project
        {
            public int Id { get; set; }
            public string Name { get; set; } = "";
            public string Status { get; set; } = "";
            public decimal Budget { get; set; }
            public decimal ActualCost { get; set; }
            public string ContractorRating { get; set; } = "";
            public string QuoteStatus { get; set; } = "";
            public string InvoiceStatus { get; set; } = "";
        }

        [BindProperty]
        public int? SelectedProjectId { get; set; }

        public Project? SelectedProject { get; set; }

        public List<SelectListItem> ProjectOptions { get; set; } = new();
        public List<Project> Projects { get; set; } = new();

        public void OnGet()
        {
            LoadProjects();
            PopulateProjectOptions();

            if (SelectedProjectId.HasValue)
            {
                SelectedProject = Projects.FirstOrDefault(p => p.Id == SelectedProjectId);
            }
        }

        public void OnPost()
        {
            LoadProjects();
            PopulateProjectOptions();

            if (SelectedProjectId.HasValue)
            {
                SelectedProject = Projects.FirstOrDefault(p => p.Id == SelectedProjectId);
            }
        }

        private void LoadProjects()
        {
            Projects = new List<Project>
            {
                new Project { Id = 1, Name = "Solar Installation - Zone A", Status = "In Progress", Budget = 120000, ActualCost = 95000, ContractorRating = "4.5", QuoteStatus = "Approved", InvoiceStatus = "Generated" },
                new Project { Id = 2, Name = "Apartment A101 Plumbing", Status = "Completed", Budget = 50000, ActualCost = 48000, ContractorRating = "4.7", QuoteStatus = "Approved", InvoiceStatus = "Generated" },
                new Project { Id = 3, Name = "Office Complex C2 Electrical", Status = "In Progress", Budget = 75000, ActualCost = 50000, ContractorRating = "4.2", QuoteStatus = "Pending", InvoiceStatus = "Pending" },
                new Project { Id = 4, Name = "Building B Exterior Painting", Status = "Pending", Budget = 60000, ActualCost = 0, ContractorRating = "0", QuoteStatus = "Pending", InvoiceStatus = "Pending" }
            };
        }

        private void PopulateProjectOptions()
        {
            ProjectOptions = Projects.Select(p => new SelectListItem
            {
                Value = p.Id.ToString(),
                Text = p.Name,
                Selected = SelectedProjectId.HasValue && SelectedProjectId.Value == p.Id
            }).ToList();
        }
    }
}
