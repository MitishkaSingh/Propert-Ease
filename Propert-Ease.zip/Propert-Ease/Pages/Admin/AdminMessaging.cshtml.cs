using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Admin
{
    public class AdminMessagingModel : PageModel
    {
        // Represents a single chat message
        public class ChatMessage
        {
            public string Sender { get; set; } = string.Empty;
            public string Text { get; set; } = string.Empty;
            public DateTime Timestamp { get; set; }
        }

        // Shared static list of messages (temporary in-memory chat)
        private static readonly List<ChatMessage> SharedMessages = new List<ChatMessage>
        {
            new ChatMessage { Sender = "Client", Text = "Good morning, I need an update on my request.", Timestamp = DateTime.Now.AddMinutes(-15) },
            new ChatMessage { Sender = "Admin", Text = "Good morning! We are currently reviewing your request.", Timestamp = DateTime.Now.AddMinutes(-10) },
            new ChatMessage { Sender = "Client", Text = "Thank you for the quick response!", Timestamp = DateTime.Now.AddMinutes(-8) }
        };

        // Bound property for the message input
        [BindProperty]
        public string NewMessage { get; set; } = string.Empty;

        // The messages displayed on the page
        public List<ChatMessage> DisplayMessages { get; set; } = new List<ChatMessage>();

        public void OnGet()
        {
            // Load messages for display
            DisplayMessages = SharedMessages.ToList();
        }

        public IActionResult OnPost()
        {
            if (!string.IsNullOrWhiteSpace(NewMessage))
            {
                // Add the admin�s message
                SharedMessages.Add(new ChatMessage
                {
                    Sender = "Admin",
                    Text = NewMessage,
                    Timestamp = DateTime.Now
                });

                // Simulate a short client reply
                SharedMessages.Add(new ChatMessage
                {
                    Sender = "Client",
                    Text = "Got it, thanks Admin!",
                    Timestamp = DateTime.Now.AddSeconds(30)
                });
            }

            // Refresh the page to show updated messages
            return RedirectToPage();
        }
    }
}