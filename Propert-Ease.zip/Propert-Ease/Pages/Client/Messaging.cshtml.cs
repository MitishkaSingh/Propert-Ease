using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Client
{
    public class MessagingModel : PageModel
    {
        [BindProperty]
        public string NewMessage { get; set; } = "";

        public List<Message> Messages { get; set; } = new List<Message>();

        public void OnGet()
        {
            // Preloaded fake conversation
            Messages = FakeConversation();
        }

        public IActionResult OnPost()
        {
            Messages = FakeConversation();

            if (!string.IsNullOrWhiteSpace(NewMessage))
            {
                Messages.Add(new Message
                {
                    Sender = "You",
                    Content = NewMessage,
                    Timestamp = DateTime.Now,
                    IsClient = true
                });

                NewMessage = string.Empty;
            }

            return Page();
        }

        private List<Message> FakeConversation()
        {
            return new List<Message>
            {
                new Message { Sender = "Contractor", Content = "Hello! How can we assist you today?", Timestamp = DateTime.Now.AddMinutes(-15), IsClient = false },
                new Message { Sender = "You", Content = "I have a maintenance request.", Timestamp = DateTime.Now.AddMinutes(-10), IsClient = true },
                new Message { Sender = "Contractor", Content = "Thanks, we will schedule it.", Timestamp = DateTime.Now.AddMinutes(-5), IsClient = false }
            };
        }
    }

    public class Message
    {
        public string Sender { get; set; } = "";
        public string Content { get; set; } = "";
        public DateTime Timestamp { get; set; }
        public bool IsClient { get; set; }
    }
}
