using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text;

namespace Propert_Ease.Pages.Client
{
    public class QuotesInvoicesModel : PageModel
    {
        [BindProperty]
        public int SelectedQuoteId { get; set; }

        public Quote? SelectedQuote { get; set; }

        public string? Message { get; set; }
        public string AlertClass { get; set; } = "alert-success";

        public List<Quote> Quotes => QuoteData.Quotes;

        public void OnGet() { }

        public void OnGetSelect(int selectedQuoteId)
        {
            SelectedQuote = Quotes.FirstOrDefault(q => q.Id == selectedQuoteId);
        }

        public IActionResult OnPostApprove()
        {
            var quote = Quotes.FirstOrDefault(q => q.Id == SelectedQuoteId);
            if (quote != null)
            {
                quote.Status = "Approved";
                Message = $"Quote #{quote.Id} approved successfully!";
                AlertClass = "alert-success";
            }
            return Page();
        }

        public IActionResult OnPostReject()
        {
            var quote = Quotes.FirstOrDefault(q => q.Id == SelectedQuoteId);
            if (quote != null)
            {
                quote.Status = "Rejected";
                Message = $"Quote #{quote.Id} rejected.";
                AlertClass = "alert-danger";
            }
            return Page();
        }

        public IActionResult OnPostDownloadInvoice()
        {
            var quote = Quotes.FirstOrDefault(q => q.Id == SelectedQuoteId);
            if (quote == null)
            {
                Message = "Quote not found.";
                AlertClass = "alert-danger";
                return Page();
            }

            // Build invoice content
            var invoiceText = $@"
Invoice for Quote #{quote.Id}
===========================
Title: {quote.Title}
Description: {quote.Description}
Amount: ${quote.Amount}
Status: {quote.Status}

Thank you for your business!
";

            // Convert text to bytes
            var bytes = Encoding.UTF8.GetBytes(invoiceText);

            // Return as downloadable file
            return File(bytes, "text/plain", $"Invoice_Quote_{quote.Id}.txt");
        }

        public string GetStatusClass(string? status)
        {
            return status switch
            {
                "Approved" => "status-approved",
                "Rejected" => "status-rejected",
                "Paid" => "status-paid",
                _ => "status-pending"
            };
        }
    }

    public class Quote
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public decimal Amount { get; set; }
        public string Status { get; set; } = "Pending";
    }

    public static class QuoteData
    {
        public static List<Quote> Quotes { get; } = new List<Quote>
        {
            new Quote { Id = 1, Title = "Leaking Faucet Repair", Description = "Fix kitchen faucet", Amount = 50 },
            new Quote { Id = 2, Title = "Broken Window Replacement", Description = "Replace bedroom window", Amount = 120 },
            new Quote { Id = 3, Title = "Electrical Wiring Check", Description = "Check living room wiring", Amount = 80 },
            new Quote { Id = 4, Title = "Garden Landscaping", Description = "Trim and tidy garden", Amount = 200 },
            new Quote { Id = 5, Title = "Roof Inspection", Description = "Inspect roof for leaks", Amount = 150 }
        };
    }
}
