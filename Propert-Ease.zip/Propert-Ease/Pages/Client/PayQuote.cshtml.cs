using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Client
{
    public class PayQuoteModel : PageModel
    {
        [BindProperty]
        public int QuoteId { get; set; }

        public decimal Amount { get; set; }

        public bool ShowSuccess { get; set; } = false;

        public void OnGet(int quoteId)
        {
            QuoteId = quoteId;

            // Load quote amount (mock)
            var quote = QuoteData.Quotes.FirstOrDefault(q => q.Id == quoteId);
            if (quote != null)
            {
                Amount = quote.Amount;
            }
        }

        public IActionResult OnPost()
        {
            var quote = QuoteData.Quotes.FirstOrDefault(q => q.Id == QuoteId);
            if (quote != null)
            {
                quote.Status = "Paid";
                Amount = quote.Amount;
            }

            // Show success message
            ShowSuccess = true;

            return Page();
        }
    }
}
