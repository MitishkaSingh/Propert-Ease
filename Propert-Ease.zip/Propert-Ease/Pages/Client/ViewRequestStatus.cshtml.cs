using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Propert_Ease.Pages.Client
{
    public class ViewRequestStatusModel : PageModel
    {
        [BindProperty]
        public int? SelectedRequestId { get; set; }

        public List<MaintenanceRequest> Requests { get; set; } = new();
        public MaintenanceRequest? SelectedRequest { get; set; }

        public void OnGet()
        {
            // Load all requests from the shared data store
            Requests = MaintenanceData.Requests;
        }

        public IActionResult OnPostSelect(int selectedId)
        {
            // Load all requests again for display
            Requests = MaintenanceData.Requests;

            // Find selected request
            SelectedRequestId = selectedId;
            SelectedRequest = MaintenanceData.Requests.FirstOrDefault(r => r.Id == selectedId);

            return Page();
        }

        public IActionResult OnPostCancel()
        {
            // Reset selected request
            Requests = MaintenanceData.Requests;
            SelectedRequest = null;
            SelectedRequestId = null;

            return Page();
        }
    }
}
