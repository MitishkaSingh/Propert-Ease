using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;

namespace Propert_Ease.Pages.Client
{
    public class RequestMaintenanceModel : PageModel
    {
        [BindProperty]
        public string RequestName { get; set; } = string.Empty;

        [BindProperty]
        public string Description { get; set; } = string.Empty;

        [BindProperty]
        public IFormFile? MediaFile { get; set; }

        public string? SuccessMessage { get; set; }

        public void OnGet() { }

        public void OnPost()
        {
            if (string.IsNullOrWhiteSpace(RequestName) || string.IsNullOrWhiteSpace(Description))
            {
                ModelState.AddModelError(string.Empty, "Please fill in all required fields.");
                return;
            }

            try
            {
                // Save maintenance request to shared static list
                MaintenanceData.Requests.Add(new MaintenanceRequest
                {
                    Id = MaintenanceData.Requests.Count + 1,
                    Name = RequestName,
                    Description = Description,
                    MediaFileName = MediaFile?.FileName ?? "No file",
                    DateSubmitted = DateTime.Now,
                    Status = "Pending"
                });

                // Show success message
                SuccessMessage = "Maintenance request submitted successfully!";

                // Clear input fields for next entry
                RequestName = string.Empty;
                Description = string.Empty;
                MediaFile = null;
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An error occurred while submitting your request: {ex.Message}");
            }
        }
    }

    public class MaintenanceRequest
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string MediaFileName { get; set; } = string.Empty;
        public DateTime DateSubmitted { get; set; }
        public string Status { get; set; } = "Pending";
    }

    public static class MaintenanceData
    {
        public static List<MaintenanceRequest> Requests { get; } = new List<MaintenanceRequest>();
    }
}
